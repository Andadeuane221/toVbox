/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/24 12:59:41 by rgouveia          #+#    #+#             */
/*   Updated: 2024/10/24 13:26:53 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src);

char	*ft_strcat(char *dest, char *src)
{
	int	sizes;
	int	sized;

	sizes = 0;
	sized = 0;
	while (dest[sized] != '\0')
		sized++;
	while (src[sizes] != '\0')
	{
		dest[sized] = src[sizes];
		sized++;
		sizes++;
	}
	dest[sized] = '\0';
	return (dest);
}
