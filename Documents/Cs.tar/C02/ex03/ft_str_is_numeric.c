/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/22 16:11:52 by rgouveia          #+#    #+#             */
/*   Updated: 2024/10/22 16:49:16 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_isnumeric(int d);
int	ft_str_is_numeric(char *str);

int	ft_isnumeric(int d)
{
	if (d >= '0' && d <= '9')
		return (1);
	return (0);
}

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	if (str[0] != '\0')
	{
		while (str[i] != '\0')
		{
			if (!ft_isnumeric(str[i]))
				return (0);
			i++;
		}
		return (1);
	}
	else
		return (1);
}
