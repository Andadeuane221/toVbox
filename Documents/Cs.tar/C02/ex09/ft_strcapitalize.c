/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/22 19:25:59 by rgouveia          #+#    #+#             */
/*   Updated: 2024/10/22 19:32:12 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcapitalize(char *str);
char	*ft_logic(char *str, int i, int capnext);

int	ft_isdigit(char c)
{
	if (c >= '0' && c <= '9')
		return (1);
	return (0);
}

int	ft_isalph(char c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
		return (1);
	return (0);
}

char	*ft_logic(char *str, int i, int capnext)
{
	while (str[i] != '\0')
	{
		if (ft_isalph(str[i]) || ft_isdigit(str[i]))
		{
			if (capnext)
			{
				if (str[i] >= 'a' && str[i] <= 'z')
					str[i] -= 32;
				capnext = 0;
			}
			else
			{
				if (str[i] >= 'A' && str[i] <= 'Z')
					str[i] += 32;
			}
		}
		else
			capnext = 1;
		i++;
	}
	return (str);
}

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	capnext;

	i = 0;
	capnext = 1;
	return (ft_logic(str, i, capnext));
}
