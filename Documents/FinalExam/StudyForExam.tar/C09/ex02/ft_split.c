/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/06 20:55:19 by rgouveia          #+#    #+#             */
/*   Updated: 2024/11/06 21:19:27 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strndup(char *src, int n)
{
	int		i;
	char	*copy;

	if (!src)
		return (NULL);
	copy = (char *)malloc((n + 1) * sizeof(char));
	if (!copy)
		return (NULL);
	i = 0;
	while (i < n)
	{
		copy[i] = src[i];
		i++;
	}
	copy[i] = '\0';
	return (copy);
}

int	ft_issep(char c, char *charset)
{
	int	i;

	i = 0;
	if (c == '\0')
		return (1);
	while (charset[i] != '\0')
	{
		if (c == (charset[i]))
			return (1);
		i++;
	}
	return (0);
}

int	ft_countwords(char *str, char *charset)
{
	int	i;
	int	nb;

	nb = 0;
	if (!ft_issep(str[0], charset))
		nb++;
	i = 1;
	while (str[i] != '\0')
	{
		if (!ft_issep(str[i], charset) && \
			ft_issep(str[i - 1], charset))
			nb++;
		i++;
	}
	return (nb);
}

char	**ft_split(char *str, char *charset)
{
	char	**tab;
	int		i;
	int		j;
	int		k;
	int		len;

	len = ft_countwords(str, charset);
	tab = (char **)malloc((len + 1) * sizeof(char *));
	k = 0;
	i = 0;
	while (str[i] != '\0')
	{
		j = 0;
		while (!ft_issep(str[i + j], charset))
			j++;
		if (j)
		{
			tab[k] = ft_strndup(&str[i], j);
			k++;
			i += j;
		}
		i++;
	}
	tab[k] = 0;
	return (tab);
}
