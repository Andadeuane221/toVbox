/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/22 10:03:58 by rgouveia          #+#    #+#             */
/*   Updated: 2024/10/22 10:15:38 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcpy(char *dest, char *src);

char	*ft_strcpy(char *dest, char *src)
{
	char	*final_dest;

	final_dest = dest;
	while (*src)
	{
		*dest++ = *src++;
	}
	*dest = '\0';
	return (final_dest);
}
