/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_memory.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/23 13:17:01 by rgouveia          #+#    #+#             */
/*   Updated: 2024/10/25 07:59:59 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_chkspc(int count)
{
	if (count < 40)
	{
		while (count < 40)
		{
			write(1, " ", 1);
			count++;
		}
	}
}

void	ft_printaddr(void *addr)
{
	long	add;
	long	i;

	i = 15;
	add = (long)addr;
	while (i >= 0)
	{
		ft_putchar("0123456789abcdef" [(add >> (i * 4)) & 0xF]);
		i--;
	}
	write(1, ":", 1);
	write(1, " ", 1);
}

int	ft_prmemo_logic(unsigned char *addr, unsigned int size)
{
	unsigned int	count;
	unsigned int	i;

	i = 0;
	count = 0;
	ft_printaddr(addr);
	while (i < size)
	{
		ft_putchar("0123456789abcdef" [(addr[i] >> 4) & 0xF]);
		ft_putchar("0123456789abcdef" [addr[i] & 0xF]);
		count += 2;
		if ((i + 1) % 2 == 0 && (i + 1) < size)
		{
			write(1, " ", 1);
			count++;
		}
		i++;
	}
	return (count);
}

void	*ft_print_memory(void *addr, unsigned int size)
{
	unsigned int	aux;
	unsigned int	tmp;
	unsigned char	*byte_addr;

	byte_addr = (unsigned char *)addr;
	aux = ft_prmemo_logic(byte_addr, size);
	ft_chkspc(aux);
	tmp = 0;
	while (tmp < size)
	{
		if (byte_addr[tmp] >= 32 && byte_addr[tmp] <= 126)
			ft_putchar(byte_addr[tmp]);
		else
			ft_putchar('.');
		tmp++;
	}
	return (addr);
}
