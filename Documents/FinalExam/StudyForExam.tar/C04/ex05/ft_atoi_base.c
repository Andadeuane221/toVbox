/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/29 17:37:49 by rgouveia          #+#    #+#             */
/*   Updated: 2024/10/29 18:21:34 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

int	ft_baseisvalid(char *base)
{
	int	i;
	int	j;

	if (ft_strlen(base) < 2)
		return (0);
	i = 0;
	while (base[i] != '\0')
	{
		if (base[i] == '+' || base[i] == '-' || base[i] == ' '
			|| base[i] == '\t' || base[i] == '\n' || base[i] == '\v'
			|| base[i] == '\f' || base[i] == '\r')
			return (0);
		j = 0;
		while (base[j] != '\0')
		{
			if (j != i && base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	if (i < 2)
		return (0);
	return (1);
}

int	ft_pow(int base, int expo)
{
	int	aux;

	aux = 1;
	while (expo > 0)
	{
		aux *= base;
		expo--;
	}
	return (aux);
}

int	ft_posinbase(char c, char *base)
{
	int	i;

	i = 0;
	while (base[i] != c)
		i++;
	return (i);
}

int	ft_atoi_base(char *str, char *base)
{
	int	rad;
	int	i;
	int	j;
	int	nbr;

	if (!ft_baseisvalid(base))
		return (0);
	nbr = 0;
	rad = 0;
	while (base[rad])
		rad++;
	i = 0;
	while (str[i])
		i++;
	j = 0;
	while (--i >= 0)
	{
		nbr += ft_pow(rad, i) * ft_posinbase(str[j], base);
		j++;
	}
	return (nbr);
}
