/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/28 10:30:50 by rgouveia          #+#    #+#             */
/*   Updated: 2024/10/28 13:09:25 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_special_case(void)
{
	char	*special_case;

	special_case = "-2147483648";
	while (*special_case)
	{
		ft_putchar(*special_case);
		special_case++;
	}
}

void	ft_print(int nb)
{
	if (nb <= 9)
		ft_putchar(nb + '0');
	else
	{
		ft_print(nb / 10);
		ft_print(nb % 10);
	}
}

void	ft_putnbr(int nb)
{
	if (nb == -2147483648)
		ft_special_case();
	else
	{
		if (nb < 0)
		{
			write(1, "-", 1);
			nb *= -1;
		}
		ft_print(nb);
	}
}
