/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/28 13:59:17 by rgouveia          #+#    #+#             */
/*   Updated: 2024/10/29 17:36:59 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	ft_baseisvalid(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i] != '\0')
	{
		if (base[i] == '+' || base[i] == '-')
			return (0);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	if (i > 1)
		return (i);
	else
		return (0);
}

void	ft_putnbr_base_logic(int nbr, char *base, int base_len)
{
	int	i;

	if (nbr <= -base_len || nbr >= base_len)
		ft_putnbr_base_logic(nbr / base_len, base, base_len);
	i = nbr % base_len;
	if (i < 0)
		i = -i;
	ft_putchar(base[i]);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int	base_len;

	base_len = ft_baseisvalid(base);
	if (base_len)
	{
		if (nbr < 0)
			ft_putchar('-');
		ft_putnbr_base_logic(nbr, base, base_len);
	}
}
