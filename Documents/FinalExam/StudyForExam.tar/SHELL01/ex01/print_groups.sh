#!/bin/bash
id --zero -Gn $FT_USER | tr '\0' ',' | sed 's/\(.*\),/\1/'
