#!/bin/bash
echo "$(cat /etc/passwd | grep -v '^#' | awk 'NR % 2 == 0' | awk -F: '{print $1}' | rev | sort -r | sed -n '1,$p' | awk '{if(NR>1) printf ", "; printf "%s", $0} END {print "."}')"
