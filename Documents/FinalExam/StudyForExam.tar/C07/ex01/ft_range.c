/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/03 15:44:54 by rgouveia          #+#    #+#             */
/*   Updated: 2024/11/03 17:03:41 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	len;
	int	*range;

	if (max > min)
	{
		len = max - (min);
		range = (int *)malloc(len * sizeof(int));
		len = 0;
		while (min < max)
		{
			range[len] = min;
			min++;
			len++;
		}
		return (range);
	}
	else
		return (NULL);
}
