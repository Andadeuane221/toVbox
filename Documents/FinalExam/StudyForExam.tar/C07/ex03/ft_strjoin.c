/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/03 18:04:25 by rgouveia          #+#    #+#             */
/*   Updated: 2024/11/03 19:12:15 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len] != '\0')
		len++;
	return (len);
}

char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

int	ft_totallen(int size, char **strs, char *sep)
{
	int	totallen;
	int	seplen;
	int	i;

	totallen = 0;
	seplen = ft_strlen(sep);
	i = 0;
	while (i < size)
	{
		totallen += ft_strlen(strs[i]);
		i++;
	}
	totallen += seplen * (size - 1);
	return (totallen);
}

char	*ft_strcat_sep(char *result, char **strs, char *sep, int size)
{
	int	pos;
	int	i;
	int	j;

	pos = 0;
	i = 0;
	while (i < size)
	{
		j = 0;
		while (strs[i][j])
		{
			result[pos++] = strs[i][j++];
		}
		if (i < size - 1)
		{
			j = 0;
			while (sep[j])
			{
				result[pos++] = sep[j++];
			}
		}
		i++;
	}
	result[pos] = '\0';
	return (result);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		totallen;
	char	*result;

	if (size == 0)
	{
		result = (char *)malloc(1);
		if (result)
			result[0] = '\0';
		return (result);
	}
	totallen = ft_totallen(size, strs, sep);
	result = (char *)malloc((totallen + 1) * sizeof(char));
	if (!result)
		return (NULL);
	return (ft_strcat_sep(result, strs, sep, size));
}
