/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/01 09:35:51 by rgouveia          #+#    #+#             */
/*   Updated: 2024/11/01 10:21:26 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	main(int ac, char **av)
{
	if (ac > 1)
	{
		av++;
		while (*av)
		{
			while (**av)
			{
				ft_putchar(**av);
				(*av)++;
			}
			write(1, "\n", 1);
			av++;
		}
	}
}
