/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/21 12:40:22 by rgouveia          #+#    #+#             */
/*   Updated: 2024/10/21 13:09:18 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size);

void	ft_sort_int_tab(int *tab, int size)
{
	int	tmp;
	int	aux1;
	int	aux2;

	aux1 = 0;
	while (aux1 < size - 1)
	{
		aux2 = 0;
		while (aux2 < size - 1)
		{
			if (aux2 + 1 < size)
			{
				if (tab[aux2] > tab[aux2 + 1])
				{
					tmp = tab[aux2];
					tab[aux2] = tab[aux2 + 1];
					tab[aux2 + 1] = tmp;
				}
			}
			aux2++;
		}
		aux1++;
	}
}
