/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/30 18:48:59 by rgouveia          #+#    #+#             */
/*   Updated: 2024/10/31 11:15:32 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_itepow(int nb, int power)
{
	int	aux;
	int	res;

	aux = 0;
	res = 1;
	if (nb < 0)
	{
		nb *= -1;
		aux = 1;
	}
	while (power >= 1)
	{
		res *= nb;
		power--;
	}
	if (aux)
		return (res * -1);
	else
		return (res);
}

int	ft_iterative_power(int nb, int power)
{
	if (power < 0)
		return (0);
	else if (nb == 0 || power == 0)
		return (1);
	else if (power == 1)
		return (nb);
	else
		return (ft_itepow(nb, power));
}
