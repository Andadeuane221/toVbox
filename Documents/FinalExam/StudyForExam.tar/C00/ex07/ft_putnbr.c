/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/20 20:45:49 by rgouveia          #+#    #+#             */
/*   Updated: 2024/10/20 23:38:07 by rgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr(int nb);
void	ft_print(int nb);
void	ft_putchar(char c);
void	ft_special_case(void);

void	ft_print(int nb)
{
	if (nb <= 9)
		ft_putchar(nb + '0');
	else
	{
		ft_print(nb / 10);
		ft_print(nb % 10);
	}
}

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_special_case(void)
{
	ft_putchar('-');
	ft_putchar('2');
	ft_putchar('1');
	ft_putchar('4');
	ft_putchar('7');
	ft_putchar('4');
	ft_putchar('8');
	ft_putchar('3');
	ft_putchar('6');
	ft_putchar('4');
	ft_putchar('8');
}

void	ft_putnbr(int nb)
{
	if (nb == -2147483648)
		ft_special_case();
	else
	{
		if (nb < 0)
		{
			write(1, "-", 1);
			nb *= -1;
		}
		ft_print(nb);
	}
}
