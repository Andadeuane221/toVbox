#!/bin/bash
git ls-files --exclude-standard --others --ignored
